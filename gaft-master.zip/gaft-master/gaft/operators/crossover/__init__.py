''' Package for built-in crossover operators '''

